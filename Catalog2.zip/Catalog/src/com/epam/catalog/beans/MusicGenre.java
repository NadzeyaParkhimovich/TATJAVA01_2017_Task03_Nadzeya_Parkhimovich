package com.epam.catalog.beans;

public enum MusicGenre {
	ROCK,
	METAL,
	POP,
	JAZZ,
	BLUES,
	ELECTRO;
}