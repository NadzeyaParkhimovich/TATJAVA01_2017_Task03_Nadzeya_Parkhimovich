package com.epam.catalog.beans;

public class PeaceOfNews {
	private String text;
	private Tag tag;
	
	public PeaceOfNews() {
		
	}
	
	public PeaceOfNews(Tag tag, String text) {
		this.tag = tag;
		this.text = text;
	}
	
	public Tag getTag() {
		return tag;
	}
	
	public String getText() {
		return text;
	}
	
	public void setTag(Tag tag) {
		this.tag = tag;
	}
	
	public void setText(String text) {
		this.text = text;
	}

}
