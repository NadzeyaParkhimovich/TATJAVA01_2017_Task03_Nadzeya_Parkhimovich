package com.epam.catalog.dao;

import java.util.ArrayList;
import com.epam.catalog.beans.PeaceOfNews;

public interface NewsDAO {
	
	ArrayList<PeaceOfNews> readAllNews() throws DAOException;
	void saveNews(ArrayList<PeaceOfNews> news) throws DAOException;
	
}
