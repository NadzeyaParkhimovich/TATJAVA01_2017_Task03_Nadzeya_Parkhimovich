package com.epam.catalog.beans;

public enum FilmGenre {
	THRILLER,
	DRAMA,
	MELODRAMA,
	COMEDY,
	CARTOON;
}
