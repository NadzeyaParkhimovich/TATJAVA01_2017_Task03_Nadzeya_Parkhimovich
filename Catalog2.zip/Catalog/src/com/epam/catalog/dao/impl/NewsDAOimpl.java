package com.epam.catalog.dao.impl;

import org.xml.sax.helpers.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import org.xml.sax.*;
import com.epam.catalog.beans.PeaceOfNews;
import com.epam.catalog.dao.DAOException;
import com.epam.catalog.dao.NewsDAO;

public class NewsDAOimpl implements NewsDAO{

	String path = XMLRunner.class.getProtectionDomain().getCodeSource().getLocation().getPath();
	
	@Override
	public ArrayList<PeaceOfNews> readAllNews() throws DAOException {

			try {
				
				XMLReader xr = XMLReaderFactory.createXMLReader();
				// ������������� ���������� SAX-�������
				XMLRunner xml = new XMLRunner();
				xr.setContentHandler( xml );
				// ������ XML-����
				xr.parse(new InputSource(new FileReader(path + "/data/data.xml")));
				
				return xml.getNews();
				
			} catch (IOException | SAXException e) {
				throw new DAOException("Error in reading file");
			}	
	}
		


	@Override
	public void saveNews(ArrayList<PeaceOfNews> news) throws DAOException {
		try {
			OutputStream outputStream = new FileOutputStream(new File(path + "/data/dataOut.xml"));
	
			XMLStreamWriter out = XMLOutputFactory.newInstance().createXMLStreamWriter(
			                new OutputStreamWriter(outputStream, "utf-8"));
	
			out.writeStartDocument();
			out.writeStartElement("data");
			
			for(PeaceOfNews peaceOfNews : news) {
				out.writeStartElement("news");
				out.writeAttribute("tag", peaceOfNews.getTag().toString());
				out.writeCharacters(peaceOfNews.getText());
				out.writeEndElement();
			}
			out.writeEndElement();
			out.writeEndDocument();
	
			out.close();	
		} catch (UnsupportedEncodingException | XMLStreamException | FactoryConfigurationError | FileNotFoundException e) {
			throw new DAOException("Error in writing file");
		}
	}

}
