package com.epam.catalog.dao;

import com.epam.catalog.dao.impl.NewsDAOimpl;

public final class DAOFactory {
	
	private static final NewsDAO instance = new NewsDAOimpl();
	
	private DAOFactory(){}
	
	public static NewsDAO getInstance(){
		return instance;
	}

}