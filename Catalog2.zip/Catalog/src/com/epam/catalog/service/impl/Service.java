package com.epam.catalog.service.impl;

public class Service {

}
