package com.epam.catalog.beans;

public enum Tag {
	FILM,
	BOOK,
	MUSIC;
}
