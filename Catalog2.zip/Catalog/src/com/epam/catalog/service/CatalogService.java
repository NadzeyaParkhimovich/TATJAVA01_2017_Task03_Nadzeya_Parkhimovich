package com.epam.catalog.service;

import java.util.ArrayList;
import com.epam.catalog.beans.PeaceOfNews;
import com.epam.catalog.beans.Tag;

public interface CatalogService {
	
	ArrayList<PeaceOfNews> readAllNews() throws ServiceExeption;
	void saveNews(ArrayList<PeaceOfNews> news) throws ServiceExeption;
	ArrayList<PeaceOfNews> findNewsByTag(Tag tag);
	ArrayList<PeaceOfNews> findNewsByText(String text);
	void addNews(PeaceOfNews peaceOfNews);
	void addNews(Tag tag, String text);
	
}
