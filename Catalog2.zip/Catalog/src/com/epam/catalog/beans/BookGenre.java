package com.epam.catalog.beans;

public enum BookGenre {
	FANTAZY,
	NOVEL,
	BIOGRAPHY,
	HISTORY,
	SCIENCE;
}
