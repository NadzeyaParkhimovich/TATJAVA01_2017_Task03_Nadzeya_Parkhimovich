package com.epam.catalog.dao;

import java.util.ArrayList;
import com.epam.catalog.beans.PeaceOfNews;

public class segesg {

	public static void main(String[] args) throws Exception {
		
		
		NewsDAO reader = DAOFactory.getInstance();
		ArrayList<PeaceOfNews> news = reader.readAllNews();
		
		for(PeaceOfNews peaceOfNews : news) {
			System.out.println(peaceOfNews.getTag() + " " + peaceOfNews.getText());
		}
		reader.saveNews(news);

	}

}
